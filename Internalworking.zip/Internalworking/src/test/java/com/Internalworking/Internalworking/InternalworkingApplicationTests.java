package com.Internalworking.Internalworking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternalworkingApplicationTests {

	@Test
	void contextLoads() {
	}

}
