package com.Internalworking.Internalworking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternalworkingApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternalworkingApplication.class, args);
	}

}
